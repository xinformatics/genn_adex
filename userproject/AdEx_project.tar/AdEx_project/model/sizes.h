#define _NC1 1
#define _FTYPE GENN_FLOAT
#define scalar float
#define SCALAR_MIN 1.17549e-038f
#define SCALAR_MAX 3.40282e+038f
