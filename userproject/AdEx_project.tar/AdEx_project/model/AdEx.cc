/*--------------------------------------------------------------------------
Author: Shashank









--------------------------------------------------------------------------*/
#define DT 1.0
#include "modelSpec.h"
#include "modelSpec.cc"
#include "sizes.h"

double AdEx_p[10] = {
			//AdEx model parameters
	1,		// 0 - c (capacitance)
	5,		// 1 - g_l (conductance)
	-70.6, 	// 2 - l_v (leak_potential)
	-50.4,	// 3 - s_t (spike thresold)
	2,		// 4 - s_f (slope_factor)
	144,	// 5 - t_w (tau_w)
	1.8,	// 6 - a
	80.5,	// 7 - b
	-67.35,	// 8 - v_r (reset potential)
	4.0     // 9 - I0 (input current)
};

double AdExvar_ini[2] = {
	//AdEx model initial conditions
	-67.35,	//0 - V
	0		//1 - w
};

void modelDefinition(NNmodel &model)
{
	initGeNN();
#ifndef CPU_ONLY
	model.setGPUDevice(0);
#endif
	model.setName("AdEx");
	neuronModel n;
	// variables
	n.varNames.clear();
	n.varTypes.clear();
	n.varNames.push_back(tS("V"));
	n.varTypes.push_back(tS("scalar"));
	n.varNames.push_back(tS("w"));
	n.varTypes.push_back(tS("scalar"));
	n.pNames.clear();
	// parameters
	n.pNames.push_back(tS("c"));
	n.pNames.push_back(tS("g_l"));
	n.pNames.push_back(tS("l_v"));
	n.pNames.push_back(tS("s_t"));
	n.pNames.push_back(tS("t_w")); 
	n.pNames.push_back(tS("a"));
	n.pNames.push_back(tS("b"));
	n.pNames.push_back(tS("v_r"));
	n.pNames.push_back(tS("I0"));
	n.dpNames.clear();
	

	n.simCode = tS("    if ($(V) >= 30.0){\n\
		$(V)=$(v_r);\n\
			 $(U)+=$(b);\n\
		} \n\
	 	$(V)+=0.5($(I0) - $(g_l)*($(V) - $(l_v)) + $(g_l)*$(s_f)*exp(($(V) - $(s_t))/$(s_f)) - $(w)/$(c))*DT; // at two times for numerical stability\n\
		$(V)+=0.5($(I0) - $(g_l)*($(V) - $(l_v)) + $(g_l)*$(s_f)*exp(($(V) - $(s_t))/$(s_f)) - $(w) / $(c))*DT;\n\
		$(w)+= ($(a)*($(V) - $(l_v) / $(t_w)) - ($(w) / $(t_w))*DT;\n\
		//if ($(V) > 30.0){   //keep this only for visualisation -- not really necessaary otherwise \n\
		//  $(V)=30.0;\n\
		//}\n\
		");
	n.thresholdConditionCode = tS("$(V) > 29.99");
	n.dps = NULL;
	unsigned int MYADEX = nModels.size();
	nModels.push_back(n);
	//unsigned int ADEX  = nModels.size() - 1;
	model.addNeuronPopulation("AdEx1", _NC1, MYADEX, AdEx_p, AdExvar_ini);
	model.setPrecision(GENN_FLOAT);
	model.finalize();
